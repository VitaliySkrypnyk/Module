﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modul
{
    // TODO 1: Create the JuiceType enumeration.
    public enum JuiceType
    {
        UNKNOWN,
        APPLE,
        ORANGE,
        TOMATO
    }

   
}